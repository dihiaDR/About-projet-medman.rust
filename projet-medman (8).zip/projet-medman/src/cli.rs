use std::path::PathBuf;

use structopt::StructOpt;

/// Représente les arguments en paramètres de ligne de commande
#[derive(Debug, StructOpt)]
pub struct CliArguments {
    /// Commande à exécuter
    #[structopt(subcommand)]
    pub command: Command,
}

#[derive(Debug, StructOpt)]
pub enum Command {
    Scan {
        // #[structopt(short = "p", long = "path")]  //Uncomment if you need
        // after uncommaent it , run usin ```cargo run scan -p <path>```
        // now simply cargo run scan <path>
        path : PathBuf,
    },
    Search {
        // You can remove this line if you want, 
        // Now if you need to give the params you need to use -r or --request
        // #[structopt(short = "r", long = "request")]
        request: Vec<String>,
    },
    // Subcommand write2-md for creating the md file
    Write2Md{
        path : PathBuf, query : String,
    },
    // This command is create a playlist the given path.
    Write2{
        path : PathBuf, query : String,
    }
}