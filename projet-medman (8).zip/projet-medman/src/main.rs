use medman::cli::CliArguments;
use medman::*;
use structopt::StructOpt;

fn main() {
    let args = CliArguments::from_args();
    
    match args.command {
        cli::Command::Scan { path } => {
            let result = scan(&path);
            for i in result{
                println!("{:?}",i);
            }
        }
        cli::Command::Search { request } => {
            let result = search(&request);
            println!("{:?}", result)
        }
        cli::Command::Write2Md { path, query } => {
            let result = search(&[query]);
            write2md(&result, &path)
        },
        cli::Command::Write2 { path, query } => {
            let result = search(&[query]);
            write2(&result, &path)
        },
    }
}
