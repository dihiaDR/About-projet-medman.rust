use crate::musicfile::MusicFile;
use m3u::*;
use std::{fs::File, path::Path};

// This Write2 function create a m3u playlist file.
pub fn write2(vec_music: &Vec<MusicFile>, path: &Path) {
    let mut playlist = vec![];

    // Loop throught music file and added the music path to playlist
    for entry in vec_music {
        playlist.push(m3u::path_entry(entry.path()))
    }
    let path = path.join("playlist.m3u");
    let mut file = File::create(path).unwrap();
    let mut writer = m3u::Writer::new(&mut file);
    for entry in &playlist {
        writer.write_entry(entry).unwrap();
    }
}

// test for checking the existence of the created play list
#[test]
fn test_write2() {
    let mut music_files: Vec<MusicFile> = Vec::new();
    music_files.push(MusicFile::new(
        std::path::Path::new("./test/file_example_MP3_700KB.mp3"),
        "Impact Moderato".to_string(),
        "Kevin MacLeod".to_string(),
        "YouTube Audio Library".to_string(),
    ));

    write2(&music_files, &std::path::Path::new("./test"));
    assert!(Path::new("./test/playlist.m3u").exists())
}
