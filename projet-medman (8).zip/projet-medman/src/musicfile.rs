use std::path::{Path, PathBuf};
use serde::{Serialize, Deserialize}; 

// Main struct for the Music file
#[derive(Debug, Serialize, Deserialize ,Clone,PartialEq)]
pub struct MusicFile {
    path : PathBuf, 
    album : String,
    title : String ,
    artiste : String ,
} 

// Implementing Methods for the struct
impl MusicFile {
    pub fn new(path: &Path, album : String ,title : String ,artiste : String )-> MusicFile { 
        MusicFile {
            path: path.to_path_buf(),
            album ,
            title ,
            artiste ,
        } 
    }

    pub fn path(&self) -> &str {
        self.path.to_str().unwrap()
    } 
    pub fn album(&self) -> String {
        self.album.clone()
    }
    pub fn title(&self) -> String {
        self.title.clone()
    }
    pub fn artiste(&self) -> String {
        self.artiste.clone()
    } 
    
}

impl MusicFile {
    pub fn iter(&self) -> Iter<'_> {
        Iter {
            inner: self,
            index: 0,
        }
    }
}
pub struct Iter<'a> {
    inner: &'a MusicFile,
    index: u8,
}

impl<'a> Iterator for Iter<'a> {
    type Item =  String;
    
    fn next(&mut self) -> Option<Self::Item> {
        let ret = match self.index {
            1 => self.inner.album.clone(),
            2 => self.inner.title.clone(),
            3 => self.inner.artiste.clone(),
            0 => {
                let a =self.inner.path.clone().into_os_string().into_string().unwrap();
                a
            },
            _ => return None,
        };
        self.index += 1;
        Some(ret)
    }
}