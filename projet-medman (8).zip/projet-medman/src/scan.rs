use std::path::Path;
use walkdir::{DirEntry, WalkDir};
use audiotags::Tag; 
use crate::musicfile::MusicFile; 
use std::fs::File;

const SUPPORTED_EXTENSIONS: [&str; 1] = ["mp3"];

fn is_supported(entry: &DirEntry) -> bool {
    entry.path().is_file() &&
    SUPPORTED_EXTENSIONS.contains(&entry.path().extension().unwrap().to_str().unwrap())
}

// Scan fait une recherche a partir d'un path qui peut etre un dossier ou un fichier et elle renvoie un vecteur de MusicFile 
pub fn scan(path: &Path) -> Vec<MusicFile> {
    let mut music_files: Vec<MusicFile> = Vec::new();
    let walker = WalkDir::new(path).into_iter();
    
    for entry in walker {
        match entry {
            Ok (valeurs) => 
                if(&valeurs).path().extension().is_some() {
                if is_supported(&valeurs) {
                let val = Tag::default().read_from_path(valeurs.path()).unwrap();
                music_files.push(MusicFile::new(
                    valeurs.path(),
                match val.title() {Some(e) => e.to_string(), None => "None".to_string()},
                    match val.artist() { Some(e) => e.to_string(), None => "None".to_string()},
                    match val.album_title() { Some(e) => e.to_string(), None => "None".to_string()},
                ));
            }
        }
            Err(err) => panic!("{:?}", err),
        };
    
    };
    let json_str = serde_json::to_value(&music_files).unwrap();
    // Write json to file
    // Creating a file named 'music_files.json to store the music detals.
    let write_json = File::create("music_files.json").unwrap();
    serde_json::to_writer(write_json, &json_str).expect("Unable to write file");
    music_files 
}

#[cfg(test)] 
mod tests { 
    use super::*; 

    #[test]
    fn verif_scan() {
        //Vérifie que le scan fonctionne correctement 
        let mut music_files: Vec<MusicFile> = Vec::new();
        music_files.push(MusicFile::new(
            std::path::Path::new("./test/file_example_MP3_700KB.mp3"),
            "Impact Moderato".to_string(),
            "Kevin MacLeod".to_string(),
            "YouTube Audio Library".to_string()
        ));
        let music = scan(std::path::Path::new("./test"));
        
        assert_eq!(serde_json::to_string_pretty(&music_files).unwrap(), serde_json::to_string_pretty(&music).unwrap());
    
    }
}