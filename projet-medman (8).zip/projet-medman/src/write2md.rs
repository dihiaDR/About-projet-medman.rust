use markdown_gen::markdown::{Markdown, AsMarkdown};
use std::{fs::File, path::Path};

use crate::musicfile::MusicFile;

// Function for creating the md file , taking arguments music files array and path to create the md file
pub fn write2md(musicfiles : &[MusicFile], path : &Path) {
    // creation of `seriafile.md` file in given directory
    let path = path.join("seriafile.md");
    let file = File::create(path).unwrap();
    // creating a md file
    let mut md = Markdown::new(file);
    // Adding the Music file details using loops.
    for (i, music) in musicfiles.iter().enumerate() {
        md.write(format!("No : {}, Title :  {}", (i+1).to_string(), music.title()).heading(1)).unwrap();
        md.write(format!("{}{}", "Artist : ", music.artiste()).paragraph()).unwrap();
        md.write(format!("{}{}", "Album : ", music.album()).paragraph()).unwrap();
        md.write(format!("{}{}", "Path : ", music.path()).paragraph()).unwrap();
    }
} 

// test for checking the the md file created or not
#[test]
fn test_write2md() {
    let mut music_files: Vec<MusicFile> = Vec::new();
    music_files.push(MusicFile::new(
        std::path::Path::new("./test/file_example_MP3_700KB.mp3"),
        "Impact Moderato".to_string(),
        "Kevin MacLeod".to_string(),
        "YouTube Audio Library".to_string(),
    ));

    write2md(&music_files, &std::path::Path::new("./test"));
    assert!(Path::new("./test/seriafile.md").exists())
}