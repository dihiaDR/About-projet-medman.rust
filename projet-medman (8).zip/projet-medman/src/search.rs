use std::fs;
use crate::musicfile::MusicFile;

// Search function for the request. request is an array of string
// search over the array and the similar music files are returned.
pub fn search(request: &[String]) -> Vec<MusicFile> {
    // Opening the music_file.json (Created using scan function), contains the information about the music files
    let file = fs::File::open("music_files.json").expect("Cannot find the path");
    let json: serde_json::Value =
        serde_json::from_reader(file).expect("file should be proper JSON");
    // Deserialize the JSON to Vec<MusicFile> 
    let music_files: Vec<MusicFile> = serde_json::from_value(json).unwrap();

    let mut results = Vec::new();
    // Iterate through the music_files for searching the requested music.
    music_files.iter().for_each(|files| {
        request.iter().for_each(|req| {
            let mut flag = false;
            files.iter().for_each(|media| {
                if req == &media {
                    flag = true;
                }
            });
            if flag {
                results.push(files.clone());
            }
        })
    });
    results.dedup();
    results
}
